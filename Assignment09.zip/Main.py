# ------------------------------------------------------------------------ #
# Title: Assignment 09
# Description: Working with Modules

# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created started script
# RRoot,1.1.2030,Added pseudo-code to start assignment 9
# RClabots,3.14.2022,Modified code to complete assignment 9
# ------------------------------------------------------------------------ #
# Import Modules
import DataClasses, ProcessingClasses, IOClasses
strFileName = "EmployeeData.txt"
List_Of_Employees = []

# Main Body of Script  ---------------------------------------------------- #
# Add Data Code to the Main body
# Load data from file into a list of employee objects when script starts
# Show user a menu of options
# Get user's menu option choice
    # Show user current data in the list of employee objects
    # Let user add data to the list of employee objects
    # let user save current data to file
    # Let user exit program

try:
    # Load data from file into a list of product objects when script starts
    List_Of_Employees = ProcessingClasses.FileProcessor.read_data_from_file(strFileName)
    ListOfEmployees = []

    for row in List_Of_Employees:
        ListOfEmployees.append(DataClasses.Employee(row[0], row[1], row[2]))

    while (True):
        # Show user a menu of options
        IOClasses.EmployeeIO.print_menu_items()

        # Get user's menu option choice
        choice_str = IOClasses.EmployeeIO.input_menu_options()

        # Show user current data in the list of product objects
        if choice_str.strip() == '1':
            IOClasses.EmployeeIO.print_current_list_items(ListOfEmployees)

        # Let user add data to the list of product objects
        if choice_str.strip() == '2':
            ListOfEmployees.append(IOClasses.EmployeeIO.input_employee_data())

        # let user save current data to file and exit program
        if choice_str.strip() == '3':
            ProcessingClasses.FileProcessor.save_data_to_file(strFileName, ListOfEmployees)

        if choice_str.strip() == '4':
            print("Goodbye!")
            break
except Exception as e:
    print(e, e.__doc__, type(e))

# Main Body of Script  ---------------------------------------------------- #
